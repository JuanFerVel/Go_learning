#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/source_map.cpp"
#endif

#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/environment.cpp"
#endif

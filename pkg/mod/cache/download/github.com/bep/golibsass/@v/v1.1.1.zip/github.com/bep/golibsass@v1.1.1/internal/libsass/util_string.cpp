#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/util_string.cpp"
#endif
